import java.io.*;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.mail.MultiPartEmail;

import java.util.*;

public class HashTotal {
	// count
	public static int index = 0;

	// Hash Total
	public static BigDecimal sum;
	
	// ex. NYA000000038
	public static String nyaText = "";
	// ex. 00038
	public static String nyaNumber = "";

	public static void main(String[] args) throws IOException {
		// file path
		String accPath = "D:/Prime/MEGANY/Import/Account";
		String actPath = "D:/Prime/MEGANY/Import/Activity";
		String cusPath = "D:/Prime/MEGANY/Import/Customer";
		String ofaPath = "D:/Prime/MEGANY/OFAC/Batchfilter/Input";

		// read folder
		File fileCus = new File(cusPath);
		File fileAcc = new File(accPath);
		File fileAct = new File(actPath);
		File fileOfa = new File(ofaPath);

		String[] fileNameCus = fileCus.list();
		String[] fileNameAcc = fileAcc.list();
		String[] fileNameAct = fileAct.list();
		String[] fileNameOfa = fileOfa.list();

		// read tsv file
		for (int i = 0; i < fileNameCus.length; i++) {
			if ("NEWYORK_CUSTOMER.TSV".equals(fileNameCus[i])) {
				String customer = fileNameCus[i].substring(0, fileNameCus[i].indexOf("."));
				ReadFile(cusPath + "/" + fileNameCus[i], customer);
				WriteFile("NEWYORK_CUSTOMER");
			}
		}

		for (int i = 0; i < fileNameAcc.length; i++) {
			if ("NEWYORK_ACCOUNT.TSV".equals(fileNameAcc[i])) {
				String account = fileNameAcc[i].substring(0, fileNameAcc[i].indexOf("."));
				ReadFile(accPath + "/" + fileNameAcc[i], account);
				WriteFile("NEWYORK_ACCOUNT");
			}
		}

		for (int i = 0; i < fileNameAct.length; i++) {
			if ("NEWYORK_ACTIVITY.TSV".equals(fileNameAct[i])) {
				String activity = fileNameAct[i].substring(0, fileNameAct[i].indexOf("."));
				ReadFile(actPath + "/" + fileNameAct[i], activity);
				WriteFile("NEWYORK_ACTIVITY");
			}
		}

		
		for (int i = 0; i < fileNameOfa.length; i++) {
			if ("NEWYORK_OFACCUST.TSV".equals(fileNameOfa[i]) || "NEWYORK_PEPSCUST.TSV".equals(fileNameOfa[i])) {
				String ofac = fileNameOfa[i].substring(0, fileNameOfa[i].indexOf("."));
				ReadFile(ofaPath + "/" + fileNameOfa[i], ofac);
				System.out.println("ofac = " + ofac);
				if ("NEWYORK_OFACCUST.TSV".equals(fileNameOfa[i])) {
					WriteFile("NEWYORK_OFACCUST");
				} else {
					WriteFile("NEWYORK_PEPSCUST");
				}
			}
		}
		// sendEmail("This is send mail");
		 
	}
	/**
	public static void parseData(String str, String tilde) {
		int front = 0;
		int end = 0;
		while((front = str.indexOf(tilde, end)) != -1) {
			
			//get the text between tilde
			String text = str.substring(end, front);
			
			//get NYA text
			if((front - end) == 12) {
				if("NYA".equals(text.substring(0,3))) {
					nyaNumber = text.substring(7);
					System.out.println("nyaNumber = " + nyaNumber);
				}
			}
			// get next text
			end = front + 1 ;
		}
	}
	*/

	public static void WriteFile(String fileName) throws IOException {
		SimpleDateFormat sdFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		sdFormat.format(date);

		File saveFile = new File("D:/Prime/MEGANY/HashTotal/output.txt");
		int increase = 1;
		
		while(saveFile.exists()) {
			System.out.println("saveFile.exists()");
			increase++;
			saveFile = new File("D:/Prime/MEGANY/HashTotal/output" + increase + ".txt");
		}
		if(!saveFile.exists()) {
			try {
				String content = fileName + ":" + "count = " + index + ", HashTotal = " + sum;
				saveFile.createNewFile();
				
				FileWriter fwriter = new FileWriter(saveFile.getAbsoluteFile());
				BufferedWriter bw = new BufferedWriter(fwriter);
				
				bw.write(sdFormat.format(date));
				bw.write("\n");
				bw.write(content);
				// print date
			//	fwriter.write(sdFormat.format(date));
			//	fwriter.write(System.getProperty("line.separator"));
				bw.close();
				
			//	fwriter.write(fileName + ":" + "count = " + index + ", HashTotal = " + sum);
			//	fwriter.write(System.getProperty("line.separator"));

				System.out.println("Done");
			}
			catch (IOException e) {
				
			}
		}

		// print date
	//	fwriter.write(sdFormat.format(date));
	//	fwriter.write(System.getProperty("line.separator"));

	}
	// get the NYA number ex.NYA000075010
	public static int parseTilde(String text, int fromWhich) {
		// setting parse mark
		Pattern pattern = Pattern.compile("~");
		// use the mark to parse text
		Matcher matcher1 = pattern.matcher(text);
		int count = 0;
		// start parsing
		while (matcher1.find()) {
			count++;
			if(count == fromWhich) {
				// get text1 = NYA000000038~~~~BUSINESS~0
				String text1 = text.substring(matcher1.end());
				// get nyaText = NYA000000038
				nyaText = text1.substring(0, text1.indexOf("~"));
			//	System.out.println("nyaText = " + nyaText);
				nyaNumber = nyaText.substring(nyaText.length()-5, nyaText.length());
			//	System.out.println("nyaNumber = " + nyaNumber);
			}
		}
		return count;
	}

	@SuppressWarnings("resource")
	public static void ReadFile(String path, String fileName) {
		try {
			// read file
			// setting UTF-8 format
			BufferedReader read = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf8"));

			// initial index and sum when run the new file
			index = 0;
			sum = new BigDecimal(0);
			// DecimalFormat decimalFormat=new DecimalFormat(",###");
			// decimalFormat.format(sum);

			// read each line
			while (read.ready()) {
				index += 1;
				String brStr = read.readLine();
				String numStr = "0";
				// check brStr 0-3 is NYA
				String brStr0_3 = brStr.substring(0, 3);
				String brStrAcc = brStr.substring(11,14);
				if (brStr.length() > 0) {
					// cut context to get the number
					if ("NEWYORK_CUSTOMER".equals(fileName)) {
						if ("NYA".equals(brStr0_3)) {
							numStr = brStr.substring(6, 12);
						}
					} else if ("NEWYORK_ACCOUNT".equals(fileName)) {
						if ("NYA".equals(brStrAcc)) {
							numStr = brStr.substring(29, 35);
						}
					} else if ("NEWYORK_ACTIVITY".endsWith(fileName)) {
						if ("NYA".equals(brStr0_3)) {
							numStr = brStr.substring(6, 12);
						}
					} 
					else if ("NEWYORK_OFACCUST".equals(fileName)) {
						parseTilde(brStr, 18);
						numStr = nyaNumber;
					} else if ("NEWYORK_PEPSCUST".equals(fileName)) {
						parseTilde(brStr, 18);
						numStr = nyaNumber;
					}
					
					BigDecimal numInt = new BigDecimal(0);

					// check numStr is all number
					Pattern pattern = Pattern.compile("[0-9]*");
					if (pattern.matcher(numStr).matches()) {
						// change string to number
						numInt = new BigDecimal(numStr);
						
						// numStr including non-number, replace non-number to 0
					} else {
						numStr = numStr.replaceAll("[a-zA-Z]", "0");
						numInt = new BigDecimal(numStr);
					}
					sum = sum.add(numInt);
					// sum += numInt;
				}
			} // End While

			System.out.println(fileName);
			System.out.println("Count:" + index);
			System.out.println("Hash Total:" + sum);
			System.out.println();

		} catch (Exception e) {

			e.printStackTrace();

			System.out.println(path + "read file error");
		}
		// return null;
	}
/**
	@SuppressWarnings("unused")
	private static void sendEmail(String title) {
		// writeLog("Start sending email...", false);
		try {
			MultiPartEmail email = new HtmlEmail();
			email.setSmtpPort(25);
			email.setSSLOnConnect(false);
			email.setHostName("mail.megabank.com.tw");

			email.setSendPartial(true);

			email.setFrom("y.c.jhuo@megaicbc.com.tw");
			/*
			 * for (String mail : property().getEmailTo()) { email.addTo(mail);
			 * //writeLog("Mail to : " + mail, false); }
			 
			email.addTo("y.c.jhuo@megaicbc.com");
			/*
			 * for (String mail : property().getEmailCc()) { email.addCc(mail);
			 * //writeLog("Cc to : " + mail, false); }
			 
			email.addCc("y.c.jhuo@megaicbc.com");
			email.setSubject("Prod: " + title);
			email.setMsg("<H2>See attachment for detail.</H2>");

			// writeLog("Sending Email...", false);
			EmailAttachment attachment = new EmailAttachment();
			// attachment.setPath(property.getEmailLogPath());
			attachment.setDisposition(EmailAttachment.ATTACHMENT);
			attachment.setDescription("Log of HashTotal");
			attachment.setName("HashTotal.log");
			email.attach(attachment);

			email.send();
			// writeLog("Email sent.", false);
		} catch (EmailException e) {
			// writeLog(e.toString(), true);
		}
	}
	*/
}