import java.io.*;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.mail.MultiPartEmail;

import java.util.*;

public class HashTotal {
	// count
	public static int index = 0;

	// Hash Total
	public static BigDecimal sum;

	public static void main(String[] args) throws IOException {
		// file path
		String accPath = "D:/Prime/MEGANY/Import/Account";
		String actPath = "D:/Prime/MEGANY/Import/Activity";
		String cusPath = "D:/Prime/MEGANY/Import/Customer";
		String ofaPath = "D:/Prime/MEGANY/OFAC/Batchfilter/Input";

		// read folder
		File fileCus = new File(cusPath);
		File fileAcc = new File(accPath);
		File fileAct = new File(actPath);
		File fileOfa = new File(ofaPath);

		String[] fileNameCus = fileCus.list();
		String[] fileNameAcc = fileAcc.list();
		String[] fileNameAct = fileAct.list();
		String[] fileNameOfa = fileOfa.list();

		for (int i = 0; i < fileNameCus.length; i++) {
			if ("NEWYORK_CUSTOMER.TSV".equals(fileNameCus[i])) {
				String customer = fileNameCus[i].substring(0, fileNameCus[i].indexOf("."));
				ReadFile(cusPath + "/" + fileNameCus[i], customer);
				WriteFile("NEWYORK_CUSTOMER");
			}
		}

		for (int i = 0; i < fileNameAcc.length; i++) {
			if ("NEWYORK_ACCOUNT.TSV".equals(fileNameAcc[i])) {
				String account = fileNameAcc[i].substring(0, fileNameAcc[i].indexOf("."));
				ReadFile(accPath + "/" + fileNameAcc[i], account);
				WriteFile("NEWYORK_ACCOUNT");
			}
		}

		for (int i = 0; i < fileNameAct.length; i++) {
			if ("NEWYORK_ACTIVITY.TSV".equals(fileNameAct[i])) {
				String activity = fileNameAct[i].substring(0, fileNameAct[i].indexOf("."));
				ReadFile(actPath + "/" + fileNameAct[i], activity);
				WriteFile("NEWYORK_ACTIVITY");
			}
		}

		/**
		for (int i = 0; i < fileNameOfa.length; i++) {
			if ("NEWYORK_OFACCUST.TSV".equals(fileNameOfa[i]) || "NEWYORK_PEPSCUST.TSV".equals(fileNameOfa[i])) {
				String ofac = fileNameOfa[i].substring(0, fileNameOfa[i].indexOf("."));
				ReadFile(ofaPath + "/" + fileNameOfa[i], ofac);
				System.out.println("ofac = " + ofac);
				if ("NEWYORK_OFACCUST.TSV".equals(fileNameOfa[i])) {
					WriteFile("NEWYORK_OFACCUST");
				} else {
					WriteFile("NEWYORK_PEPSCUST");
				}
			}
		}
		// sendEmail("This is send mail");
		 */
	}

	@SuppressWarnings("resource")
	public static void WriteFile(String fileName) throws IOException {

		SimpleDateFormat sdFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		sdFormat.format(date);

		File saveFile = new File("D:/Prime/MEGANY/HashTotal/output.txt");
		FileWriter fwriter = new FileWriter(saveFile, true);

		// print date
		fwriter.write(sdFormat.format(date));

		fwriter.write(System.getProperty("line.separator"));

		try {
			fwriter.write(fileName + ":" + "count = " + index + ", HashTotal = " + sum);
			fwriter.write(System.getProperty("line.separator"));
		} catch (IOException e) {
			System.out.println("write file error");
			e.printStackTrace();
		}
		fwriter.close();
	}

	@SuppressWarnings("resource")
	public static void ReadFile(String path, String fileName) {
		try {
			// read file
			// setting UTF-8 format
			BufferedReader read = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf8"));

			// initial index and sum when run the new file
			index = 0;
			sum = new BigDecimal(0);
			// DecimalFormat decimalFormat=new DecimalFormat(",###");
			// decimalFormat.format(sum);

			// read each line
			while (read.ready()) {
				index += 1;
				String brStr = read.readLine();
				String numStr = "0";
				// check brStr 0-3 is NYA
				String brStr0_3 = brStr.substring(0, 3);
				String brStrAcc = brStr.substring(11,14);
				if (brStr.length() > 0) {
					// cut context to get the number
					if ("NEWYORK_CUSTOMER".equals(fileName)) {
						if ("NYA".equals(brStr0_3)) {
							numStr = brStr.substring(6, 12);
						}
					} else if ("NEWYORK_ACCOUNT".equals(fileName)) {
						if ("NYA".equals(brStrAcc)) {
							numStr = brStr.substring(29, 35);
						}
					} else if ("NEWYORK_ACTIVITY".endsWith(fileName)) {
						if ("NYA".equals(brStr0_3)) {
							numStr = brStr.substring(7, 12);
						}
					} 
					/**
					else if ("NEWYORK_OFACCUST".equals(fileName)) {
						// check NYA left is ~
						String indexColumn = brStr.substring(brStr.indexOf("NYA") - 1);
						// System.out.println("brStr01 = " + indexColumn.substring(0, 1));
						// System.out.println("brStr1314 = " + indexColumn.substring(13, 14));
						// System.out.println("brStr813 = " + indexColumn.substring(8, 13));
						// if("~".equals(indexColumn.substring(0, 1)) &&
						// "~".equals(indexColumn.substring(13,14))){
						numStr = indexColumn.substring(8, 13);
						// }
					} else if ("NEWYORK_PEPSCUST".equals(fileName)) {
						// check NYA left is ~
						String indexColumn = brStr.substring(brStr.indexOf("NYA") - 1);
						if ("~".equals(indexColumn.substring(0, 1)) && "~".equals(indexColumn.substring(13, 14))) {
							numStr = indexColumn.substring(8, 13);
						}
					}
					 */
					BigDecimal numInt = new BigDecimal(0);

					// check numStr is all number
					Pattern pattern = Pattern.compile("[0-9]*");
					if (pattern.matcher(numStr).matches()) {
						// change string to number
						numInt = new BigDecimal(numStr);
						
						// numStr including non-number, replace non-number to 0
					} else {
						numStr = numStr.replaceAll("[a-zA-Z]", "0");
						numInt = new BigDecimal(numStr);
					}
					sum = sum.add(numInt);
					// sum += numInt;
				}
			} // End While

			System.out.println(fileName);
			System.out.println("Count:" + index);
			System.out.println("Hash Total:" + sum);
			System.out.println();

		} catch (Exception e) {

			e.printStackTrace();

			System.out.println(path + "read file error");
		}
		// return null;
	}
/**
	@SuppressWarnings("unused")
	private static void sendEmail(String title) {
		// writeLog("Start sending email...", false);
		try {
			MultiPartEmail email = new HtmlEmail();
			email.setSmtpPort(25);
			email.setSSLOnConnect(false);
			email.setHostName("mail.megabank.com.tw");

			email.setSendPartial(true);

			email.setFrom("y.c.jhuo@megaicbc.com.tw");
			/*
			 * for (String mail : property().getEmailTo()) { email.addTo(mail);
			 * //writeLog("Mail to : " + mail, false); }
			 
			email.addTo("y.c.jhuo@megaicbc.com");
			/*
			 * for (String mail : property().getEmailCc()) { email.addCc(mail);
			 * //writeLog("Cc to : " + mail, false); }
			 
			email.addCc("y.c.jhuo@megaicbc.com");
			email.setSubject("Prod: " + title);
			email.setMsg("<H2>See attachment for detail.</H2>");

			// writeLog("Sending Email...", false);
			EmailAttachment attachment = new EmailAttachment();
			// attachment.setPath(property.getEmailLogPath());
			attachment.setDisposition(EmailAttachment.ATTACHMENT);
			attachment.setDescription("Log of HashTotal");
			attachment.setName("HashTotal.log");
			email.attach(attachment);

			email.send();
			// writeLog("Email sent.", false);
		} catch (EmailException e) {
			// writeLog(e.toString(), true);
		}
	}
	*/
}